"use client"
import SearchResultsPage from "./search-results/page"

export default function SearchResults() {
  return <SearchResultsPage />
}
