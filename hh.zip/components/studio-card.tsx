// Remove the StudioCard component. All partner cards should use the unified PartnerCard instead.
